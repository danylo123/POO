/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoinstancia;

/**
 *
 * @author Danylo
 */
public class Carro {
    public String marca;
    public String placa;
    public String cor;
    public String velocidadeMax;
    public String preco;
}
