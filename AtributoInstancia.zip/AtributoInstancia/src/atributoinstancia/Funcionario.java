/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoinstancia;

/**
 *
 * @author Danylo
 */
public class Funcionario {
    
    public String nome;
    public int idade;
    public String salario;
    public String funcao;
    public String empresa;
    
}
