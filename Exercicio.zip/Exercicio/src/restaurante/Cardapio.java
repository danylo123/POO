/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

/**
 *
 * @author LABORATORIO 01
 */
public class Cardapio {

    private String nomePrato;
    private double valor;

    public Cardapio(String nomePrato, double valor) {
        this.nomePrato = nomePrato;
        this.valor = valor;
    }

    /**
     * @return the nomePrato
     */
    public String getNomePrato() {
        return nomePrato;
    }

    /**
     * @param nomePrato the nomePrato to set
     */
    public void setNomePrato(String nomePrato) {
        this.nomePrato = nomePrato;
    }

    /**
     * @return the valor
     */
    public double getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(double valor) {
        this.valor = valor;
    }

}
