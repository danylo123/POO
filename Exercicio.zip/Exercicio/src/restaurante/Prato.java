/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

/**
 *
 * @author LABORATORIO 01
 */
public class Prato extends Cardapio{
    
    private String ingredientes;
    private String cozinheiro;
    
    public Prato(String nomePrato, double valor, String ingredientes, String cozinheiro){
        super(nomePrato, valor);
        
        this.ingredientes = ingredientes;
        this.cozinheiro = cozinheiro;
    }

    /**
     * @return the ingredientes
     */
    public String getIngredientes() {
        return ingredientes;
    }

    /**
     * @param ingredientes the ingredientes to set
     */
    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    /**
     * @return the cozinheiro
     */
    public String getCozinheiro() {
        return cozinheiro;
    }

    /**
     * @param cozinheiro the cozinheiro to set
     */
    public void setCozinheiro(String cozinheiro) {
        this.cozinheiro = cozinheiro;
    }
    
}
