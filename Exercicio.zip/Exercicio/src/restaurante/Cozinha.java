/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

/**
 *
 * @author LABORATORIO 01
 */
public class Cozinha extends Prato{
    
    private String tempoPreparo;
    private String chef;
    
    public Cozinha(String nomePrato, double valor, String ingredientes, String cozinheiro, String tempoPreparo, String chef){
        super(nomePrato, valor, ingredientes, cozinheiro);
        this.tempoPreparo = tempoPreparo;
        this.chef = chef;
    }

    /**
     * @return the tempoPreparo
     */
    public String getTempoPreparo() {
        return tempoPreparo;
    }

    /**
     * @param tempoPreparo the tempoPreparo to set
     */
    public void setTempoPreparo(String tempoPreparo) {
        this.tempoPreparo = tempoPreparo;
    }

    /**
     * @return the chef
     */
    public String getChef() {
        return chef;
    }

    /**
     * @param chef the chef to set
     */
    public void setChef(String chef) {
        this.chef = chef;
    }
    
}
