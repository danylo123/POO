/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

/**
 *
 * @author LABORATORIO 01
 */
public class Garcom extends Pessoa{
    
    private String horarioAtendimento;
    private String gorjeta;
    public Garcom(String nome, String cidade, String horarioAtendimento, String gorjeta){
        super(nome, cidade);
        
        this.horarioAtendimento = horarioAtendimento;
        this.gorjeta = gorjeta;
        
    }

    /**
     * @return the horarioAtendimento
     */
    public String getHorarioAtendimento() {
        return horarioAtendimento;
    }

    /**
     * @param horarioAtendimento the horarioAtendimento to set
     */
    public void setHorarioAtendimento(String horarioAtendimento) {
        this.horarioAtendimento = horarioAtendimento;
    }

    /**
     * @return the gorjeta
     */
    public String getGorjeta() {
        return gorjeta;
    }

    /**
     * @param gorjeta the gorjeta to set
     */
    public void setGorjeta(String gorjeta) {
        this.gorjeta = gorjeta;
    }
}
