/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import cliente.ClienteFisico;
import conta.ContaFisica;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    public static void main(String[] args) {
        ClienteFisico cliente = new ClienteFisico("Danylo", "123456789-88");
        
        ContaFisica conta = new ContaFisica(cliente , "12345-5", "8798-4");
        
        
        System.out.println(conta.getCliente().getCpf());
    }
    
}
