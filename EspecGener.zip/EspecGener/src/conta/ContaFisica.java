/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conta;

import cliente.ClienteFisico;

/**
 *
 * @author LABORATORIO 01
 */
public class ContaFisica extends Conta{
    private ClienteFisico cliente;
    
    public ContaFisica(ClienteFisico cliente, String numConta, String numAgencia){
        super(numAgencia, numConta);
        this.cliente = cliente;
    }

    /**
     * @return the cliente
     */
    public ClienteFisico getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(ClienteFisico cliente) {
        this.cliente = cliente;
    }
    
}
