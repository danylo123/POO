/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import conta.ContaCorrente;
import conta.ContaPoupanca;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {

    public static void main(String[] args) {

        ContaPoupanca cp = new ContaPoupanca("123", "123-2", 0.9);

        ContaCorrente cr = new ContaCorrente("123", "432-2", 20.53);

        System.out.println("### CONTA POUPANÇA ###");

        System.out.println(cp.getNumeroAgencia());
        System.out.println(cp.getNumeroConta());
        System.out.println(cp.getPorcentagemJurosMensal());
        cp.deposito(cp, 1000);

        System.out.println("\n");

        System.out.println("### CONTA CORRENTE ###");

        System.out.println(cr.getNumeroAgencia());
        System.out.println(cr.getNumeroConta());
        System.out.println(cr.getPorcentagemImpostoMensal());
        cr.deposito(cr, 2000);

        // Herança com construtores
    }

}
