/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoclasse;

/**
 *
 * @author Danylo
 */
public class Casa {
    
    public static boolean porta;
    public static boolean terreo;
    public static boolean telhado;
    public static boolean parede;
    public static boolean calcada;
    
    
}
