/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoclasse;

/**
 *
 * @author Danylo
 */
public class Funcionario {
    
public static boolean assistênciaMedica;
public static boolean valeAlimentacao;
public static boolean planoOdontologico;
public static boolean auxilioCreche;
public static boolean bolsasDeEstudo;
}
